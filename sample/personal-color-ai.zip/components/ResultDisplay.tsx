
import React from 'react';
import type { PersonalColorAnalysis, ColorInfo } from '../types';

interface ResultDisplayProps {
  result: PersonalColorAnalysis;
  onReset: () => void;
}

const ColorSwatch: React.FC<{ color: ColorInfo }> = ({ color }) => (
    <div className="flex flex-col items-center space-y-2 transform hover:scale-105 transition-transform">
        <div 
            className="w-16 h-16 rounded-full shadow-md border-2 border-white" 
            style={{ backgroundColor: color.hex }}
            title={`${color.name} - ${color.hex}`}
        ></div>
        <span className="text-xs text-gray-600 font-medium truncate w-20 text-center">{color.name}</span>
    </div>
);


export const ResultDisplay: React.FC<ResultDisplayProps> = ({ result, onReset }) => {
  return (
    <div className="w-full mt-8 p-6 md:p-8 bg-white/90 rounded-2xl shadow-lg border border-gray-100 text-left animate-fadeIn">
      <h2 className="text-center text-xl font-bold mb-2">Your Personal Color is...</h2>
      <p className="text-center text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-brand-secondary to-brand-primary mb-6">
        {result.personalColor}
      </p>

      <div className="mb-8">
          <h3 className="font-semibold text-lg mb-2 text-brand-text">Analysis</h3>
          <p className="text-gray-600 leading-relaxed">{result.description}</p>
      </div>
      
      <div className="mb-8">
          <h3 className="font-semibold text-lg mb-4 text-brand-text">Recommended Color Palette</h3>
          <div className="grid grid-cols-4 sm:grid-cols-5 gap-4 justify-items-center">
              {result.recommendedColors.map((color, index) => (
                  <ColorSwatch key={index} color={color} />
              ))}
          </div>
      </div>

      <div className="text-center mt-6">
        <button
          onClick={onReset}
          className="bg-brand-secondary text-white font-bold py-2 px-6 rounded-full hover:bg-brand-primary transition-colors shadow-md hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-brand-accent focus:ring-opacity-50"
        >
          Analyze Another Photo
        </button>
      </div>
    </div>
  );
};
