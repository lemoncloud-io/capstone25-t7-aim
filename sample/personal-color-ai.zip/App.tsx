
import React, { useState, useCallback } from 'react';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { ImageUploader } from './components/ImageUploader';
import { ResultDisplay } from './components/ResultDisplay';
import { Loader } from './components/Loader';
import { analyzePersonalColor } from './services/geminiService';
import type { PersonalColorAnalysis } from './types';

const App: React.FC = () => {
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [analysisResult, setAnalysisResult] = useState<PersonalColorAnalysis | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve((reader.result as string).split(',')[1]);
      reader.onerror = (err) => reject(err);
    });
  };

  const handleImageUpload = useCallback(async (file: File) => {
    setImageFile(file);
    setImageUrl(URL.createObjectURL(file));
    setAnalysisResult(null);
    setError(null);
    setIsLoading(true);

    try {
      const base64Image = await fileToBase64(file);
      const result = await analyzePersonalColor(base64Image, file.type);
      setAnalysisResult(result);
    } catch (err) {
      console.error(err);
      setError('Failed to analyze the image. Please try another photo.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  const handleReset = useCallback(() => {
    setImageFile(null);
    setImageUrl(null);
    setAnalysisResult(null);
    setError(null);
    setIsLoading(false);
    if(imageUrl) {
        URL.revokeObjectURL(imageUrl);
    }
  }, [imageUrl]);

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <main className="flex-grow container mx-auto px-4 py-8 flex flex-col items-center justify-center">
        <div className="w-full max-w-2xl text-center">
          {!imageUrl && (
            <div className="animate-fadeIn">
              <h2 className="text-3xl font-bold mb-4 text-brand-text">Find Your Perfect Colors</h2>
              <p className="text-lg text-gray-600 mb-8">Upload a clear, well-lit photo of yourself to discover your personal color palette.</p>
              <ImageUploader onImageUpload={handleImageUpload} disabled={isLoading} />
            </div>
          )}

          {imageUrl && (
            <div className="mt-8 animate-fadeIn">
              <img src={imageUrl} alt="User upload" className="max-w-xs md:max-w-sm mx-auto rounded-xl shadow-lg border-4 border-white" />
            </div>
          )}
          
          {isLoading && (
              <div className="mt-8">
                <Loader />
                <p className="text-gray-500 mt-4 animate-pulse">Analyzing your colors... this may take a moment.</p>
              </div>
          )}

          {error && <p className="text-red-500 mt-4 font-semibold">{error}</p>}
          
          {!isLoading && analysisResult && (
            <ResultDisplay result={analysisResult} onReset={handleReset} />
          )}
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default App;
