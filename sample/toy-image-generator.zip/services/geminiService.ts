
import { GoogleGenAI, Modality } from '@google/genai';
import { fileToBase64 } from '../utils/fileUtils';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

export const transformToToyImage = async (file: File): Promise<string> => {
  const base64Image = await fileToBase64(file);
  const mimeType = file.type;

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image-preview',
    contents: {
      parts: [
        {
          inlineData: {
            data: base64Image,
            mimeType: mimeType,
          },
        },
        {
          text: '이 이미지를 다채롭고 광택이 나는 플라스틱 장난감처럼 보이도록 변형시켜주세요. 디테일은 약간 단순화되고 가장자리는 부드럽게 만들어주세요.',
        },
      ],
    },
    config: {
      responseModalities: [Modality.IMAGE, Modality.TEXT],
    },
  });
  
  // The API can return multiple parts, we need to find the image part.
  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) {
      const base64ImageBytes = part.inlineData.data;
      const imageMimeType = part.inlineData.mimeType;
      return `data:${imageMimeType};base64,${base64ImageBytes}`;
    }
  }

  throw new Error("AI가 이미지를 반환하지 않았습니다.");
};
