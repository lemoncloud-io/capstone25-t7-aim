
export interface ColorInfo {
  name: string;
  hex: string;
}

export interface PersonalColorAnalysis {
  personalColor: string;
  description: string;
  recommendedColors: ColorInfo[];
}
