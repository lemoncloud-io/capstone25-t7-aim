
import React from 'react';
import { AIResponse } from '../types';
import LoadingSpinner from './LoadingSpinner';
import { LightBulbIcon, QuoteIcon } from './IconComponents';

interface ResultDisplayProps {
  result: AIResponse | null;
  isLoading: boolean;
  error: string | null;
}

const ResultDisplay: React.FC<ResultDisplayProps> = ({ result, isLoading, error }) => {
  const renderContent = () => {
    if (isLoading) {
      return <LoadingSpinner />;
    }
    if (error) {
      return (
        <div className="text-center p-8 bg-red-50 border border-red-200 rounded-lg">
          <p className="text-red-600 font-semibold">오류 발생</p>
          <p className="text-red-500 mt-2">{error}</p>
        </div>
      );
    }
    if (!result) {
      return (
        <div className="text-center p-8 bg-slate-50 border border-slate-200 rounded-lg">
          <p className="text-slate-500">당신의 단점을 입력하고 '강점 변환하기'를 눌러주세요.</p>
        </div>
      );
    }
    return (
      <div className="space-y-6">
        <div className="bg-white p-6 rounded-xl shadow-md border border-slate-200 animate-fade-in-up">
            <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2 mb-3">
                <QuoteIcon className="w-5 h-5 text-blue-500" />
                AI 리프레이밍 문장
            </h3>
            <p className="text-slate-700 text-lg md:text-xl leading-relaxed">
                "{result.reframedSentence}"
            </p>
        </div>
        <div className="bg-blue-50 p-6 rounded-xl shadow-md border border-blue-200 animate-fade-in-up" style={{ animationDelay: '150ms' }}>
            <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2 mb-3">
                <LightBulbIcon className="w-5 h-5 text-blue-500" />
                AI 피드백 및 활용법
            </h3>
            <p className="text-slate-600 whitespace-pre-wrap leading-relaxed">
                {result.feedback}
            </p>
        </div>
      </div>
    );
  };

  return (
    <div className="w-full mt-8">
      <h2 className="text-2xl font-bold text-slate-800 mb-4 text-center">AI 변환 결과</h2>
      <div className="bg-slate-100 p-4 sm:p-6 rounded-lg min-h-[200px] flex items-center justify-center">
        {renderContent()}
      </div>
    </div>
  );
};

export default ResultDisplay;
