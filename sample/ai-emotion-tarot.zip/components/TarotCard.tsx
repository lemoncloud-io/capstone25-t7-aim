
import React from 'react';
import type { TarotResult } from '../types';

interface TarotCardProps {
  result: TarotResult;
}

export const TarotCard: React.FC<TarotCardProps> = ({ result }) => {
  return (
    <div className="w-full max-w-sm md:max-w-md lg:max-w-lg animate-fade-in-up">
      <div className="bg-black/30 backdrop-blur-md rounded-2xl shadow-2xl shadow-purple-900/50 p-6 flex flex-col items-center space-y-6">
        <div className="w-full aspect-[3/4] rounded-lg overflow-hidden shadow-lg shadow-purple-500/30 transition-all duration-300 hover:shadow-xl hover:shadow-purple-400/50 hover:scale-105">
          <img
            src={result.imageUrl}
            alt={result.cardName}
            className="w-full h-full object-cover"
          />
        </div>
        <div className="text-center">
          <h2 className="text-3xl font-bold text-amber-300 tracking-wider">
            {result.cardName}
          </h2>
          <p className="mt-4 text-lg text-gray-200 leading-relaxed whitespace-pre-wrap">
            {result.interpretation}
          </p>
        </div>
      </div>
    </div>
  );
};
