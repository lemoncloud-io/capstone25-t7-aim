
export interface TarotResult {
  imageUrl: string;
  interpretation: string;
  cardName: string;
}
