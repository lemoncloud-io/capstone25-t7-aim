
import React, { useState, useEffect } from 'react';

const loadingMessages = [
  "별들의 속삭임을 듣는 중...",
  "디지털 에테르를 읽는 중...",
  "운명의 실을 잣는 중...",
  "영혼의 카드를 소환하는 중...",
];

export const LoadingSpinner: React.FC = () => {
  const [messageIndex, setMessageIndex] = useState(0);

  useEffect(() => {
    const intervalId = setInterval(() => {
      setMessageIndex((prevIndex) => (prevIndex + 1) % loadingMessages.length);
    }, 2000);

    return () => clearInterval(intervalId);
  }, []);

  return (
    <div className="flex flex-col items-center justify-center space-y-4 text-center">
      <div className="w-16 h-16 border-4 border-t-4 border-t-purple-400 border-gray-600 rounded-full animate-spin"></div>
      <p className="text-lg text-purple-300 transition-opacity duration-500">
        {loadingMessages[messageIndex]}
      </p>
    </div>
  );
};
