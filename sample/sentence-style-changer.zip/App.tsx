
import React, { useState, useCallback } from 'react';
import type { StyleVariations } from './types';
import { changeSentenceStyle } from './services/geminiService';
import StyleCard from './components/StyleCard';
import Loader from './components/Loader';
import { WandSparklesIcon, FeatherIcon, ZapIcon, ThumbsUpIcon, BriefcaseIcon } from './components/icons';

const styleOrder: (keyof StyleVariations)[] = ['polite', 'professional', 'direct', 'humorous', 'poetic'];

const styleConfig: { [key in keyof StyleVariations]: { title: string; icon: React.ReactNode } } = {
  polite: { title: '공손하게', icon: <FeatherIcon className="w-5 h-5" /> },
  professional: { title: '전문적으로', icon: <BriefcaseIcon className="w-5 h-5" /> },
  direct: { title: '직설적으로', icon: <ZapIcon className="w-5 h-5" /> },
  humorous: { title: '재치있게', icon: <ThumbsUpIcon className="w-5 h-5" /> },
  poetic: { title: '시적으로', icon: <WandSparklesIcon className="w-5 h-5" /> },
};


const App: React.FC = () => {
  const [inputText, setInputText] = useState<string>('이 보고서는 별로야.');
  const [results, setResults] = useState<StyleVariations | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = useCallback(async () => {
    if (!inputText.trim() || isLoading) return;

    setIsLoading(true);
    setError(null);
    setResults(null);

    try {
      const data = await changeSentenceStyle(inputText);
      setResults(data);
    } catch (err: unknown) {
      if (err instanceof Error) {
        setError(err.message);
      } else {
        setError('알 수 없는 오류가 발생했습니다.');
      }
    } finally {
      setIsLoading(false);
    }
  }, [inputText, isLoading]);

  const handleKeyPress = (event: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      handleSubmit();
    }
  };


  return (
    <div className="min-h-screen bg-slate-900 text-white font-sans">
      <div className="absolute inset-0 -z-10 h-full w-full bg-slate-900 bg-[linear-gradient(to_right,#8080800a_1px,transparent_1px),linear-gradient(to_bottom,#8080800a_1px,transparent_1px)] bg-[size:14px_24px]">
        <div className="absolute left-0 right-0 top-0 -z-10 m-auto h-[310px] w-[310px] rounded-full bg-indigo-500 opacity-20 blur-[100px]"></div>
      </div>
      
      <main className="container mx-auto px-4 py-8 md:py-16">
        <div className="max-w-3xl mx-auto flex flex-col items-center text-center">
          
          <header className="mb-10">
            <h1 className="text-4xl md:text-5xl font-bold tracking-tight text-slate-100">
              문장 스타일 체인저
            </h1>
            <p className="mt-4 text-lg text-slate-400">
              하나의 문장을 Gemini AI를 통해 다양한 톤앤매너로 바꿔보세요.
            </p>
          </header>

          <div className="w-full bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-4 shadow-2xl">
            <textarea
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="변환할 문장을 입력하세요..."
              className="w-full h-24 p-4 bg-transparent text-slate-200 placeholder-slate-500 rounded-md resize-none focus:outline-none focus:ring-2 focus:ring-indigo-500 transition"
              disabled={isLoading}
            />
            <div className="mt-3 flex justify-end">
              <button
                onClick={handleSubmit}
                disabled={isLoading || !inputText.trim()}
                className="flex items-center justify-center gap-2 px-6 py-3 bg-indigo-600 text-white font-semibold rounded-full shadow-lg hover:bg-indigo-700 disabled:bg-slate-600 disabled:cursor-not-allowed transition-all duration-300 transform hover:scale-105 disabled:scale-100"
              >
                {isLoading ? (
                  <>
                    <div className="w-5 h-5 border-2 border-t-transparent border-white rounded-full animate-spin"></div>
                    <span>변환 중...</span>
                  </>
                ) : (
                  <>
                    <WandSparklesIcon className="w-5 h-5" />
                    <span>스타일 변환하기</span>
                  </>
                )}
              </button>
            </div>
          </div>
          
          <div className="w-full mt-12">
            {isLoading && <Loader />}
            {error && <div className="bg-red-900/50 border border-red-500 text-red-300 px-4 py-3 rounded-lg">{error}</div>}
            {results && (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 text-left">
                {styleOrder.map((key) => {
                  const config = styleConfig[key];
                  const value = results[key];
                  if (!config || !value) return null;
                  return <StyleCard key={key} title={config.title} text={value} icon={config.icon} />;
                })}
              </div>
            )}
             {!isLoading && !results && !error && (
              <div className="text-center py-10">
                <p className="text-slate-500">결과가 여기에 표시됩니다.</p>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
};

export default App;
