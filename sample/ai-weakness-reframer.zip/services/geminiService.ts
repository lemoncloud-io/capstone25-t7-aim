
import { GoogleGenAI, Type } from '@google/genai';
import { Tone } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

const getPrompt = (weakness: string, tone: Tone): string => {
  return `
    You are an expert career coach and branding consultant who excels at reframing perceived weaknesses into powerful strengths. Your name is '리프레이머' (Reframer).
    A user will provide a weakness. Your task is to transform it into a positive self-introduction sentence and provide actionable feedback.

    The user has provided the following weakness: "${weakness}"
    They want the output in the following tone: "${tone}"

    Based on this, generate a JSON object with two properties:
    1. "reframedSentence": A single, polished sentence in Korean that rephrases the weakness as a strength, tailored to the selected tone.
        - For '자기소개' (Self-introduction): A general, positive statement.
        - For '인터뷰' (Interview): A professional statement suitable for a job interview.
        - For 'SNS': A short, catchy, and inspiring phrase.
    2. "feedback": Constructive advice in Korean on how to use this new sentence. Explain which situations it's best for (e.g., job interviews, networking, personal branding on SNS, self-reflection) and suggest how to make it even more impactful (e.g., "For an interview, pair this with a specific example where this trait led to a positive outcome."). The feedback should be encouraging and insightful.

    Example:
    Weakness: "결정을 잘 못 해요." (I'm bad at making decisions.)
    Tone: "인터뷰" (Interview)

    Expected JSON Output:
    {
      "reframedSentence": "저는 신중하게 여러 가능성을 검토하여 최적의 결정을 내리고자 노력하는 편입니다.",
      "feedback": "이 표현은 면접에서 당신의 신중함과 분석적인 태도를 어필하기에 좋습니다. '실제로 여러 옵션을 비교 분석하여 프로젝트 리스크를 줄였던 경험'과 같은 구체적인 사례를 함께 제시하면 신뢰도를 더욱 높일 수 있습니다."
    }

    Now, process the user's input. Ensure the entire output is a valid JSON object.
    `;
};


export const reframeWeakness = async (weakness: string, tone: Tone) => {
  if (!process.env.API_KEY) {
    throw new Error('API_KEY is not set');
  }

  try {
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: getPrompt(weakness, tone),
        config: {
            responseMimeType: 'application/json',
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    reframedSentence: { 
                        type: Type.STRING,
                        description: 'The rephrased positive sentence in Korean.'
                    },
                    feedback: {
                        type: Type.STRING,
                        description: 'Actionable feedback and advice in Korean.'
                    }
                },
                required: ['reframedSentence', 'feedback']
            }
        }
    });
    
    const text = response.text;
    const cleanedText = text.replace(/```json|```/g, '').trim();
    return JSON.parse(cleanedText);

  } catch (error) {
    console.error('Error calling Gemini API:', error);
    throw new Error('AI 응답을 생성하는 데 실패했습니다. 다시 시도해주세요.');
  }
};
