
import React from 'react';
import { SparklesIcon } from './IconComponents';

const Header: React.FC = () => {
  return (
    <header className="text-center p-4">
      <h1 className="text-4xl md:text-5xl font-bold text-slate-800 bg-clip-text text-transparent bg-gradient-to-r from-blue-500 to-teal-400 flex items-center justify-center gap-3">
        <SparklesIcon className="w-8 h-8 md:w-10 md:h-10" />
        단점 리프레이머
      </h1>
      <p className="mt-3 text-lg text-slate-600">당신의 약점을 가장 빛나는 강점으로 바꿔보세요.</p>
    </header>
  );
};

export default Header;
