
import React from 'react';

interface WeaknessInputProps {
  weakness: string;
  setWeakness: (weakness: string) => void;
  onSubmit: () => void;
  isLoading: boolean;
}

const WeaknessInput: React.FC<WeaknessInputProps> = ({ weakness, setWeakness, onSubmit, isLoading }) => {
  return (
    <div className="w-full">
      <label htmlFor="weakness-input" className="block text-lg font-semibold text-slate-700 mb-2">
        1. 당신의 단점을 솔직하게 적어보세요.
      </label>
      <textarea
        id="weakness-input"
        value={weakness}
        onChange={(e) => setWeakness(e.target.value)}
        placeholder="예: 결정을 잘 못해요, 게으른 편이에요, 사람들 앞에서 긴장을 많이 해요..."
        className="w-full h-32 p-4 border border-slate-300 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition duration-150 ease-in-out resize-none"
        disabled={isLoading}
      />
      <button
        onClick={onSubmit}
        disabled={!weakness || isLoading}
        className="mt-4 w-full bg-blue-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-slate-400 disabled:cursor-not-allowed transition-all duration-200 ease-in-out transform hover:scale-105 flex items-center justify-center gap-2"
      >
        {isLoading ? (
          <>
            <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
            변환 중...
          </>
        ) : (
          'AI로 강점 변환하기 ✨'
        )}
      </button>
    </div>
  );
};

export default WeaknessInput;
