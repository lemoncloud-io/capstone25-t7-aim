
import React, { useState, useCallback } from 'react';
import { generateTarotCardConcept, generateTarotImage, interpretTarotCard } from './services/geminiService';
import type { TarotResult } from './types';
import { LoadingSpinner } from './components/LoadingSpinner';
import { TarotCard } from './components/TarotCard';

const StarIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
    <path fillRule="evenodd" d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.006 5.404.434c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.434 2.082-5.005Z" clipRule="evenodd" />
  </svg>
);

const App: React.FC = () => {
  const [userInput, setUserInput] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [tarotResult, setTarotResult] = useState<TarotResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleGetReading = useCallback(async (event: React.FormEvent) => {
    event.preventDefault();
    if (!userInput.trim()) {
      setError('마음을 한 줄로 표현해주세요.');
      return;
    }

    setIsLoading(true);
    setError(null);
    setTarotResult(null);

    try {
      const { cardName, imagePrompt } = await generateTarotCardConcept(userInput);
      
      const [imageUrl, interpretation] = await Promise.all([
        generateTarotImage(imagePrompt, cardName),
        interpretTarotCard(userInput, cardName, imagePrompt)
      ]);

      setTarotResult({ imageUrl, interpretation, cardName });
    } catch (err) {
      console.error(err);
      setError('카드를 만드는 데 실패했습니다. 잠시 후 다시 시도해주세요.');
    } finally {
      setIsLoading(false);
    }
  }, [userInput]);

  const renderContent = () => {
    if (isLoading) {
      return <LoadingSpinner />;
    }
    if (error) {
      return <p className="text-red-400 bg-red-900/50 p-4 rounded-lg">{error}</p>;
    }
    if (tarotResult) {
      return <TarotCard result={tarotResult} />;
    }
    return (
      <div className="text-center text-gray-400 max-w-md">
        <h2 className="text-2xl font-semibold text-gray-200 mb-2">마음의 소리에 귀 기울여 보세요</h2>
        <p>지금 어떤 감정을 느끼고 있나요? 당신의 마음을 한 문장으로 표현하면, AI가 그 감정을 담은 특별한 타로 카드를 만들어 드립니다.</p>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 via-indigo-950 to-black text-white flex flex-col items-center justify-center p-4 selection:bg-purple-500/30">
      <main className="w-full max-w-2xl flex flex-col items-center space-y-12 my-10">
        <header className="text-center">
          <div className="flex justify-center items-center gap-4">
             <StarIcon className="w-8 h-8 text-amber-300" />
             <h1 className="text-4xl md:text-5xl font-bold tracking-tight bg-gradient-to-r from-amber-200 to-purple-400 text-transparent bg-clip-text">
              AI 감정 타로
            </h1>
             <StarIcon className="w-8 h-8 text-amber-300" />
          </div>
          <p className="mt-4 text-lg text-indigo-300">당신의 감정을 위한 단 하나의 타로 카드</p>
        </header>

        <form onSubmit={handleGetReading} className="w-full max-w-lg flex items-center bg-black/20 backdrop-blur-sm p-2 rounded-full border border-purple-800/50 shadow-lg shadow-purple-900/50 focus-within:border-purple-500 transition-colors">
          <input
            type="text"
            value={userInput}
            onChange={(e) => setUserInput(e.target.value)}
            placeholder="지금의 마음을 한 줄로 설명해주세요... (예: 나한테 왜 이러는 걸까)"
            className="flex-grow bg-transparent text-white placeholder-gray-500 px-4 py-2 outline-none"
            disabled={isLoading}
          />
          <button
            type="submit"
            disabled={isLoading}
            className="bg-purple-600 hover:bg-purple-500 disabled:bg-purple-800 disabled:text-gray-400 disabled:cursor-not-allowed text-white font-bold py-2 px-6 rounded-full transition-all duration-300 flex items-center"
          >
            {isLoading ? '생성 중...' : '카드 보기'}
          </button>
        </form>

        <div className="w-full flex justify-center items-center min-h-[400px]">
          {renderContent()}
        </div>
      </main>
      <footer className="text-center text-gray-600 py-4 text-sm">
        <p>Powered by Google Gemini. For entertainment purposes only.</p>
      </footer>
    </div>
  );
};

export default App;
