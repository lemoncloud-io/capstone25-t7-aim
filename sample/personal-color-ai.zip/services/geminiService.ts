
import { GoogleGenAI, Type } from "@google/genai";
import type { PersonalColorAnalysis } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const personalColorSchema = {
  type: Type.OBJECT,
  properties: {
    personalColor: {
      type: Type.STRING,
      description: "The user's personal color season, e.g., 'Spring Warm', 'Summer Cool', 'Autumn Warm', 'Winter Cool'."
    },
    description: {
      type: Type.STRING,
      description: "A detailed explanation of the analysis, covering skin tone, hair, and eye color characteristics that led to the conclusion."
    },
    recommendedColors: {
      type: Type.ARRAY,
      description: "A list of 8-10 recommended colors that suit this personal color type.",
      items: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING, description: "The name of the color, e.g., 'Ivory', 'Peach', 'Light Moss Green'." },
          hex: { type: Type.STRING, description: "The hex code for the color, e.g., '#FFFFF0', '#FFDAB9', '#8FBC8F'." }
        },
        required: ['name', 'hex']
      }
    }
  },
  required: ['personalColor', 'description', 'recommendedColors']
};


export const analyzePersonalColor = async (imageBase64: string, mimeType: string): Promise<PersonalColorAnalysis> => {
    const prompt = `You are an expert personal color analyst. Based on the provided user's photo, analyze their skin tone, eye color, and hair color to determine their personal color season (Spring Warm, Summer Cool, Autumn Warm, Winter Cool). Provide a detailed description of why you chose that season and a list of recommended colors with their hex codes. The photo should be of a person's face. If it is not, state that a proper photo is needed. Respond ONLY with the JSON object defined in the schema.`;

    const imagePart = {
        inlineData: {
            data: imageBase64,
            mimeType: mimeType,
        },
    };

    const textPart = {
        text: prompt,
    };
    
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: { parts: [imagePart, textPart] },
            config: {
                responseMimeType: 'application/json',
                responseSchema: personalColorSchema,
            }
        });

        const jsonText = response.text.trim();
        const result = JSON.parse(jsonText);
        
        // Basic validation
        if (!result.personalColor || !result.description || !result.recommendedColors) {
            throw new Error("Invalid response format from API.");
        }
        
        return result as PersonalColorAnalysis;
    } catch (error) {
        console.error("Error calling Gemini API:", error);
        throw new Error("Failed to get analysis from the AI model.");
    }
};
