
import React from 'react';

const LoadingSpinner: React.FC = () => {
  return (
    <div className="flex flex-col items-center justify-center space-y-4 p-8">
      <div className="w-12 h-12 border-4 border-blue-400 border-t-transparent border-solid rounded-full animate-spin"></div>
      <p className="text-slate-500 text-center">AI가 당신의 강점을 찾고 있어요... ✨</p>
    </div>
  );
};

export default LoadingSpinner;
