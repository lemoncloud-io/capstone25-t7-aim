import React, { useState, useCallback, useMemo } from 'react';
import { getTravelRecommendations } from './services/geminiService';
import { TravelIcon, SearchIcon, LoadingSpinner, ErrorIcon, MapPinIcon, UtensilsIcon, LightbulbIcon } from './components/icons';

interface RecommendationSection {
  title: string;
  content: string;
}

const iconMap: { [key: string]: React.FC<React.SVGProps<SVGSVGElement>> } = {
  '🗺️': MapPinIcon,
  '🍽️': UtensilsIcon,
  '💡': LightbulbIcon,
};

const RecommendationCard: React.FC<{ title: string; content: string; }> = ({ title, content }) => {
  const emoji = title.match(/(\p{Emoji})/u)?.[0];
  const Icon = emoji ? iconMap[emoji] : LightbulbIcon;
  const cleanTitle = title.replace(/(\p{Emoji})/u, '').trim();

  return (
    <div className="bg-stone-50 rounded-xl border border-stone-200 shadow-sm overflow-hidden transform transition-transform duration-300 hover:scale-[1.02] hover:shadow-lg">
      <div className="p-5">
        <div className="flex items-center gap-3 mb-3">
          {Icon && <Icon className="h-6 w-6 text-orange-500" />}
          <h3 className="text-lg font-bold text-stone-800">{cleanTitle}</h3>
        </div>
        <div className="text-stone-600 whitespace-pre-wrap leading-relaxed pl-9">
          {content.split('\n- ').filter(item => item.trim()).map((item, index) => (
            <p key={index} className="relative before:content-['•'] before:absolute before:left-[-1em] before:text-orange-500">{item}</p>
          ))}
        </div>
      </div>
    </div>
  );
};

const SkeletonCard: React.FC = () => (
    <div className="bg-stone-50 rounded-xl border border-stone-200 shadow-sm p-5">
        <div className="flex items-center gap-3 mb-4">
            <div className="h-6 w-6 rounded-full bg-stone-200"></div>
            <div className="h-5 w-3/5 rounded bg-stone-200"></div>
        </div>
        <div className="space-y-3 pl-9">
            <div className="h-4 w-4/5 rounded bg-stone-200"></div>
            <div className="h-4 w-full rounded bg-stone-200"></div>
            <div className="h-4 w-3/4 rounded bg-stone-200"></div>
        </div>
    </div>
);

const App: React.FC = () => {
  const [destination, setDestination] = useState<string>('');
  const [recommendations, setRecommendations] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleSearch = useCallback(async (searchQuery: string) => {
    if (!searchQuery.trim() || isLoading) return;

    setDestination(searchQuery);
    setIsLoading(true);
    setError(null);
    setRecommendations(null);

    try {
      const result = await getTravelRecommendations(searchQuery);
      setRecommendations(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
    } finally {
      setIsLoading(false);
    }
  }, [isLoading]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleSearch(destination);
  };
  
  const handleInspirationClick = (city: string) => {
    handleSearch(city);
  };

  const { title, sections } = useMemo(() => {
    if (!recommendations) return { title: null, sections: [] };

    const lines = recommendations.split('\n');
    const mainTitle = lines[0].replace('# ', '').trim();
    const restOfContent = lines.slice(1).join('\n');
    
    const parsedSections = restOfContent
      .split('### ')
      .filter(s => s.trim() !== '')
      .map(section => {
        const sectionLines = section.split('\n');
        const title = sectionLines[0].trim();
        const content = sectionLines.slice(1).join('\n').trim();
        return { title, content };
      });
    
    return { title: mainTitle, sections: parsedSections };
  }, [recommendations]);


  return (
    <div className="min-h-screen bg-stone-100 text-stone-800 font-sans flex flex-col lg:flex-row">
      <aside className="w-full lg:w-1/3 lg:max-w-sm bg-stone-50 p-6 sm:p-8 lg:h-screen lg:sticky lg:top-0 shadow-lg lg:shadow-none border-b lg:border-r border-stone-200 flex flex-col">
        <header className="mb-8">
            <div className="flex items-center gap-3 mb-2">
                <TravelIcon className="h-8 w-8 text-orange-600" />
                <h1 className="text-3xl font-bold text-stone-800">AI 여행 플래너</h1>
            </div>
            <p className="text-stone-500">가고 싶은 곳을 알려주시면 AI가 완벽한 여행 계획을 짜드려요.</p>
        </header>

        <form onSubmit={handleSubmit} className="flex items-center gap-2 mb-8">
            <input
              type="text"
              value={destination}
              onChange={(e) => setDestination(e.target.value)}
              placeholder="예: 파리, 일본, 뉴욕..."
              className="w-full bg-stone-100 text-stone-900 placeholder-stone-400 px-4 py-3 rounded-md border border-stone-200 focus:ring-2 focus:ring-orange-500 focus:border-orange-500 transition-all duration-300 outline-none"
              disabled={isLoading}
            />
            <button
              type="submit"
              disabled={isLoading || !destination.trim()}
              className="flex items-center justify-center p-3 bg-orange-600 hover:bg-orange-700 disabled:bg-stone-400 disabled:cursor-not-allowed text-white font-semibold rounded-md transition-all duration-300 shadow-md hover:shadow-lg disabled:shadow-none transform hover:scale-105 aspect-square"
              aria-label="Search"
            >
              {isLoading ? <LoadingSpinner className="h-5 w-5" /> : <SearchIcon className="h-5 w-5" />}
            </button>
        </form>

        <div className="flex-grow">
            <h2 className="text-lg font-semibold text-stone-700 mb-4">영감이 필요하신가요?</h2>
            <div className="grid grid-cols-2 gap-3">
                {['파리', '도쿄', '뉴욕', '제주도'].map(city => (
                    <button key={city} onClick={() => handleInspirationClick(city)} disabled={isLoading} className="text-left p-3 bg-stone-200/50 hover:bg-stone-200 rounded-md border border-stone-200/80 disabled:opacity-50 transition-colors duration-200">
                        <p className="font-semibold text-stone-800">{city}</p>
                    </button>
                ))}
            </div>
        </div>
        <footer className="text-center text-stone-400 mt-8">
            <p>Powered by Google Gemini</p>
        </footer>
      </aside>

      <main className="flex-grow p-6 sm:p-8 md:p-10 bg-stone-100">
        <div className="w-full max-w-4xl mx-auto">
          {isLoading && (
            <div className="animate-fade-in space-y-4">
                <div className="h-8 w-1/2 rounded bg-stone-300/80 mb-6 animate-pulse"></div>
                <SkeletonCard />
                <SkeletonCard />
                <SkeletonCard />
            </div>
          )}
          {error && (
            <div className="flex flex-col items-center justify-center h-full text-center text-red-500 animate-fade-in p-8 bg-red-50 rounded-lg border border-red-200">
              <ErrorIcon className="h-16 w-16 mb-4"/>
              <p className="text-xl font-semibold mb-2">오류가 발생했습니다</p>
              <p className="text-red-700">{error}</p>
            </div>
          )}
          {recommendations && (
             <div className="animate-fade-in">
                <h2 className="text-3xl md:text-4xl font-bold text-stone-800 mb-6 bg-clip-text text-transparent bg-gradient-to-r from-amber-500 to-orange-600">{title}</h2>
                <div className="space-y-4">
                    {sections.map((section, index) => (
                        <RecommendationCard key={index} title={section.title} content={section.content} />
                    ))}
                </div>
             </div>
          )}
          {!isLoading && !error && !recommendations && (
            <div className="flex flex-col items-center justify-center text-center h-full text-stone-500 p-8">
                <TravelIcon className="h-24 w-24 mb-6 text-stone-400"/>
                <h2 className="text-2xl font-semibold mb-2">어디로 떠나볼까요?</h2>
                <p className="max-w-md">왼쪽 검색창에 목적지를 입력하시거나 추천 도시 중 하나를 선택하여 멋진 여행 계획을 시작해보세요.</p>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default App;