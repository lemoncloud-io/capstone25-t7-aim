
import { Tone } from './types';

export const TONE_OPTIONS: { id: Tone; label: string }[] = [
  { id: Tone.SELF_INTRODUCTION, label: '자기소개용' },
  { id: Tone.INTERVIEW, label: '인터뷰용' },
  { id: Tone.SNS, label: 'SNS용' },
];
