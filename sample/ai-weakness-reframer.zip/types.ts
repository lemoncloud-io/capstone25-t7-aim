
export enum Tone {
  SELF_INTRODUCTION = '자기소개',
  INTERVIEW = '인터뷰',
  SNS = 'SNS',
}

export interface AIResponse {
  reframedSentence: string;
  feedback: string;
}
