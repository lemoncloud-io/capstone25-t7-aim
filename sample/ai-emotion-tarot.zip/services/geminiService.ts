
import { GoogleGenAI, Type } from "@google/genai";

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

interface TarotConcept {
  cardName: string;
  imagePrompt: string;
}

// Generates a symbolic name and a detailed image prompt for a tarot card
export async function generateTarotCardConcept(feeling: string): Promise<TarotConcept> {
  const model = "gemini-2.5-pro";
  const prompt = `You are a mystical tarot card creator. Based on the emotion '${feeling}', generate a name and a detailed, visually rich description for a new, unique tarot card. The description should be a prompt for an AI image generator. The output must be in JSON format.`;

  const responseSchema = {
    type: Type.OBJECT,
    properties: {
      cardName: {
        type: Type.STRING,
        description: "A mystical and symbolic name for the tarot card, in Korean.",
      },
      imagePrompt: {
        type: Type.STRING,
        description: "A detailed, visually rich description of the card's imagery for an AI image generator. Focus on symbols, colors, and mood. In English.",
      },
    },
    required: ["cardName", "imagePrompt"],
  };

  const response = await ai.models.generateContent({
    model,
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema,
    },
  });

  const jsonText = response.text.trim();
  return JSON.parse(jsonText);
}

// Generates a tarot card image from a prompt
export async function generateTarotImage(prompt: string, cardName: string): Promise<string> {
  const model = "imagen-4.0-generate-001";
  const fullPrompt = `Tarot card art for a card named "${cardName}". ${prompt}. Cinematic, hyper-detailed, epic, fantasy, intricate, elegant, highly detailed, digital painting, artstation, concept art, smooth, sharp focus, illustration. Golden intricate border around the card.`;
  
  const response = await ai.models.generateImages({
    model,
    prompt: fullPrompt,
    config: {
      numberOfImages: 1,
      outputMimeType: "image/jpeg",
      aspectRatio: "3:4",
    },
  });

  if (response.generatedImages && response.generatedImages.length > 0) {
    const base64ImageBytes = response.generatedImages[0].image.imageBytes;
    return `data:image/jpeg;base64,${base64ImageBytes}`;
  }
  
  throw new Error("Image generation failed.");
}

// Generates an interpretation for the created tarot card
export async function interpretTarotCard(feeling: string, cardName: string, cardDescription: string): Promise<string> {
  const model = "gemini-2.5-flash";
  const prompt = `You are a wise and empathetic tarot reader. A person is feeling '${feeling}'. You have drawn a special card for them called '${cardName}'. The card is described as: '${cardDescription}'. Provide a short, insightful, and comforting interpretation in Korean of what this card means for their current situation. Speak directly to the person. Keep it to 2-4 concise sentences.`;

  const response = await ai.models.generateContent({
    model,
    contents: prompt,
  });

  return response.text;
}
