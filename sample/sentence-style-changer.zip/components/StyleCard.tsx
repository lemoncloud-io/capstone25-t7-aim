
import React, { useState, useCallback } from 'react';
import { ClipboardIcon, CheckIcon } from './icons';

interface StyleCardProps {
  title: string;
  text: string;
  icon: React.ReactNode;
}

const StyleCard: React.FC<StyleCardProps> = ({ title, text, icon }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = useCallback(() => {
    navigator.clipboard.writeText(text).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  }, [text]);

  return (
    <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6 shadow-lg transition-all duration-300 hover:border-indigo-500/50 hover:bg-slate-800/70">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <span className="text-indigo-400">{icon}</span>
          <h3 className="text-lg font-semibold text-slate-200">{title}</h3>
        </div>
        <button
          onClick={handleCopy}
          className="p-2 rounded-full text-slate-400 hover:bg-slate-700 hover:text-white transition-colors focus:outline-none focus:ring-2 focus:ring-indigo-500"
          aria-label="Copy text"
        >
          {copied ? <CheckIcon className="w-5 h-5 text-green-400" /> : <ClipboardIcon className="w-5 h-5" />}
        </button>
      </div>
      <p className="text-slate-300 leading-relaxed">{text}</p>
    </div>
  );
};

export default StyleCard;
