
import React from 'react';

const PaletteIcon: React.FC = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-brand-secondary" viewBox="0 0 20 20" fill="currentColor">
    <path fillRule="evenodd" d="M4 2a2 2 0 00-2 2v12a2 2 0 002 2h12a2 2 0 002-2V4a2 2 0 00-2-2H4zm10.5 5.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-3.5 3a1.5 1.5 0 100-3 1.5 1.5 0 000 3zm-3.5-1.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zM9 14.5a1.5 1.5 0 100-3 1.5 1.5 0 000 3z" clipRule="evenodd" />
  </svg>
);

export const Header: React.FC = () => {
  return (
    <header className="bg-white/80 backdrop-blur-md shadow-sm sticky top-0 z-10">
      <div className="container mx-auto px-4 py-3 flex items-center justify-center">
        <PaletteIcon />
        <h1 className="text-2xl font-bold ml-3 text-brand-text tracking-wide">
          Personal Color <span className="text-brand-primary">AI</span>
        </h1>
      </div>
    </header>
  );
};
