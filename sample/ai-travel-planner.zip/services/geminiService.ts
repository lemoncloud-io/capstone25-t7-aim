import { GoogleGenAI } from "@google/genai";

const getTravelRecommendations = async (destination: string): Promise<string> => {
  if (!process.env.API_KEY) {
    throw new Error("API key is not configured. Please set the API_KEY environment variable.");
  }
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const prompt = `"${destination}"에 대한 여행 정보를 추천해줘. 한국어로 답변해줘. 다음과 같은 형식으로 정보를 구성해줘:

# ${destination} 여행 추천

### 🗺️ 꼭 방문해야 할 명소
- [장소 1]: [설명]
- [장소 2]: [설명]
- [장소 3]: [설명]

### 🍽️ 추천 음식
- [음식 1]: [설명]
- [음식 2]: [설명]
- [음식 3]: [설명]

### 💡 여행 팁
- [팁 1]: [설명]
- [팁 2]: [설명]

각 항목에 대해 자세하고 흥미로운 정보를 제공해줘.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
    });
    
    // Check for empty or invalid response
    if (!response.text || response.text.trim() === '') {
        throw new Error("AI returned an empty response. The destination might be invalid.");
    }
    
    return response.text;
  } catch (error) {
    console.error("Error fetching travel recommendations:", error);
    // Provide a more user-friendly error message
    if (error instanceof Error && error.message.includes('API key not valid')) {
        throw new Error("The configured API key is invalid. Please check your configuration.");
    }
    throw new Error("AI로부터 추천을 받는 데 실패했습니다. 잠시 후 다시 시도해주세요.");
  }
};

export { getTravelRecommendations };
