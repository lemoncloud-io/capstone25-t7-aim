
import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-white/50 text-center py-4 mt-8 border-t border-gray-200">
      <p className="text-gray-500">
        Powered by Gemini AI
      </p>
    </footer>
  );
};
