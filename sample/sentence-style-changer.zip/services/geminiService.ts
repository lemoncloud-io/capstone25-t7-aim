
import { GoogleGenAI, Type } from '@google/genai';
import type { StyleVariations } from '../types';

// This is a placeholder for the API key. In a real environment, 
// this would be securely managed.
if (!process.env.API_KEY) {
  // In a real app, you'd want to handle this more gracefully.
  // For this example, we'll log an error.
  console.error("API_KEY environment variable not set.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

const model = 'gemini-2.5-flash';

const responseSchema = {
  type: Type.OBJECT,
  properties: {
    polite: {
      type: Type.STRING,
      description: 'The sentence rewritten in a very polite and gentle tone.',
    },
    direct: {
      type: Type.STRING,
      description: 'The sentence rewritten in a direct, to-the-point tone.',
    },
    poetic: {
      type: Type.STRING,
      description: 'The sentence rewritten with emotional and poetic expressions.',
    },
    humorous: {
      type: Type.STRING,
      description: 'The sentence rewritten in a witty and humorous tone.',
    },
    professional: {
      type: Type.STRING,
      description: 'The sentence rewritten in an objective, professional business tone.',
    },
  },
  required: ['polite', 'direct', 'poetic', 'humorous', 'professional'],
};


export const changeSentenceStyle = async (sentence: string): Promise<StyleVariations> => {
  if (!sentence.trim()) {
    throw new Error('Input sentence cannot be empty.');
  }

  const prompt = `
    다음 문장을 아래의 5가지 스타일로 변환해주세요. 결과는 반드시 JSON 형식으로 반환해야 합니다. 각 키는 영문 소문자로, 값은 변환된 한국어 문장으로 작성해주세요.

    1. polite (매우 공손하고 부드러운 톤)
    2. direct (핵심을 짚는 직설적인 톤)
    3. poetic (감성적이고 시적인 표현)
    4. humorous (재치있고 유머러스한 톤)
    5. professional (객관적이고 전문적인 비즈니스 톤)

    변환할 원본 문장: "${sentence}"
  `;

  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: responseSchema,
        temperature: 0.8,
      },
    });
    
    const jsonText = response.text.trim();
    // Gemini can sometimes wrap the JSON in ```json ... ```, so we need to clean it.
    const cleanedJsonText = jsonText.replace(/^```json\s*|```$/g, '');
    const parsedData = JSON.parse(cleanedJsonText);
    
    return parsedData as StyleVariations;
  } catch (error) {
    console.error('Error calling Gemini API:', error);
    throw new Error('AI 응답을 받아오는 데 실패했습니다. 잠시 후 다시 시도해주세요.');
  }
};
