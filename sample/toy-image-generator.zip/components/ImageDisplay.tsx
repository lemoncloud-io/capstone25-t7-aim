
import React from 'react';
import { Loader } from './Loader';
import { ImageIcon } from './icons/ImageIcon';

interface ImageDisplayProps {
  imageUrl: string | null;
  isLoading: boolean;
  error: string | null;
}

export const ImageDisplay: React.FC<ImageDisplayProps> = ({ imageUrl, isLoading, error }) => {
  return (
    <div className="w-full aspect-square bg-slate-100 rounded-xl border-2 border-slate-200 flex items-center justify-center text-slate-500 relative overflow-hidden">
      {isLoading && (
        <div className="absolute inset-0 bg-white/80 backdrop-blur-sm flex flex-col items-center justify-center z-10">
          <Loader />
          <p className="mt-4 text-slate-600 font-semibold">AI가 장난감을 만들고 있어요...</p>
        </div>
      )}
      {error && !isLoading && (
        <div className="text-center text-red-500 p-4">
          <p className="font-bold">오류 발생!</p>
          <p className="text-sm">{error}</p>
        </div>
      )}
      {!isLoading && !error && !imageUrl && (
        <div className="text-center p-4">
            <ImageIcon className="w-12 h-12 mx-auto text-slate-400 mb-2"/>
            <p className="font-semibold">결과가 여기에 표시됩니다</p>
        </div>
      )}
      {imageUrl && (
        <img src={imageUrl} alt="Toy" className="w-full h-full object-cover" />
      )}
    </div>
  );
};
