
import React from 'react';
import { Tone } from '../types';
import { TONE_OPTIONS } from '../constants';

interface ToneSelectorProps {
  selectedTone: Tone;
  setSelectedTone: (tone: Tone) => void;
  isLoading: boolean;
}

const ToneSelector: React.FC<ToneSelectorProps> = ({ selectedTone, setSelectedTone, isLoading }) => {
  return (
    <div className="w-full">
      <h2 className="text-lg font-semibold text-slate-700 mb-3">2. 어떤 스타일로 바꿀까요?</h2>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {TONE_OPTIONS.map((option) => (
          <button
            key={option.id}
            onClick={() => setSelectedTone(option.id)}
            disabled={isLoading}
            className={`px-4 py-3 rounded-lg font-semibold text-center transition duration-200 ease-in-out border-2 ${
              selectedTone === option.id
                ? 'bg-blue-500 border-blue-500 text-white shadow-lg'
                : 'bg-white border-slate-300 text-slate-700 hover:bg-slate-50 hover:border-blue-400'
            } disabled:opacity-50 disabled:cursor-not-allowed`}
          >
            {option.label}
          </button>
        ))}
      </div>
    </div>
  );
};

export default ToneSelector;
