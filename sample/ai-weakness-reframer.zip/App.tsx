
import React, { useState, useCallback } from 'react';
import { Tone, AIResponse } from './types';
import Header from './components/Header';
import WeaknessInput from './components/WeaknessInput';
import ToneSelector from './components/ToneSelector';
import ResultDisplay from './components/ResultDisplay';
import { reframeWeakness } from './services/geminiService';

const App: React.FC = () => {
  const [weakness, setWeakness] = useState<string>('');
  const [selectedTone, setSelectedTone] = useState<Tone>(Tone.INTERVIEW);
  const [result, setResult] = useState<AIResponse | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = useCallback(async () => {
    if (!weakness.trim()) return;

    setIsLoading(true);
    setError(null);
    setResult(null);

    try {
      const aiResponse = await reframeWeakness(weakness, selectedTone);
      setResult(aiResponse);
    } catch (err: unknown) {
      if (err instanceof Error) {
        setError(err.message);
      } else {
        setError('알 수 없는 오류가 발생했습니다.');
      }
    } finally {
      setIsLoading(false);
    }
  }, [weakness, selectedTone]);

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900">
      <main className="container mx-auto max-w-2xl px-4 py-8 md:py-12">
        <Header />
        <div className="mt-10 bg-white p-6 md:p-8 rounded-2xl shadow-lg border border-slate-200 space-y-8">
          <ToneSelector 
            selectedTone={selectedTone}
            setSelectedTone={setSelectedTone}
            isLoading={isLoading}
          />
          <WeaknessInput
            weakness={weakness}
            setWeakness={setWeakness}
            onSubmit={handleSubmit}
            isLoading={isLoading}
          />
        </div>
        <ResultDisplay result={result} isLoading={isLoading} error={error} />
      </main>
      <style>{`
        .animate-fade-in-up {
          animation: fadeInUp 0.5s ease-out forwards;
          opacity: 0;
        }
        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </div>
  );
};

export default App;
