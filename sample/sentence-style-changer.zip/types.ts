
export interface StyleVariations {
  polite: string;
  direct: string;
  poetic: string;
  humorous: string;
  professional: string;
}
